﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace FaresZoghbi_FinalProject
{
    public partial class NewOrder : System.Web.UI.Page
    {
        int dp;
        int sp;
        int Total;
        int ID;
        int PizzaID;
        DateTime now;
        protected void Page_Load(object sender, EventArgs e)
        {
            string userName = Session["name"].ToString();
            string id = Session["id"].ToString();
            if (id == "6")
            {
               Manger.Visible = true;
            }
            ID = Int32.Parse(id);

            Label.Text = "Welcome " + userName;
            Label1.Text = "You can Custom Your Pizza  here !";
            Label2.Text = "ID: " + id;

            string size = DropDownListSize.Text;
            Size.Text = size;
            string top1 = DropDownListTop1.Text;
            Top1.Text = top1;
            string top2 = DropDownListTop2.Text;
            Top2.Text = top2;
            string drinkname = DropDownListDrink.Text;
            DrinkName.Text = drinkname;


            if (size == "S")
            {
                sp = 10;
                string ps = "10.00";
                LableSizePrice.Text = ps;
            }
            else if (size == "M")
            {
                sp = 12;
                string ps = "12.00";
               LableSizePrice.Text = ps;
            }
            else if (size == "L")
            {
                sp = 14;
                string ps = "14.00";
                LableSizePrice.Text = ps;
            }
            else if (size == "XL")
            {
                sp = 18;
                string ps = "18.00";
                LableSizePrice.Text = ps;
            }

            if (drinkname == "none")
            {

                dp = 0;
                string pd = "0.00";
                DrinkPrice.Text = pd;
            }
            else if (drinkname == "Coke")
            {
                dp = 2;
                string pd = "2.00";
                DrinkPrice.Text = pd;
            }
            else if (drinkname == "Dite-Coke")
            {
                dp = 2;
                string pd = "2.00";
                DrinkPrice.Text = pd;
            }
            else if (drinkname == "liquid-schwartz")
            {
                dp = 20;
                string pd = "20.00";
                DrinkPrice.Text = pd;
            }
            else if (drinkname == "red-balls")
            {
                dp = 4;
                string pd = "4.00";
                DrinkPrice.Text = pd;
            }
            Total = dp + sp;
            TotalPrice.Text = "" + (Total*1.0);




        }
        protected void Wizard1_NextButtonClick(object sender, WizardNavigationEventArgs e)
        {
            if (Wizard1.ActiveStepIndex == 1)
            {
                if (RadioButton1.Checked)
                    Wizard1.ActiveStepIndex = 2;
                else
                    Wizard1.ActiveStepIndex = 3;
            }
        }

        protected void OrderNow_Click(object sender, EventArgs e)
        {
            SqlConnection thisConnection
            = new SqlConnection(ConfigurationManager.ConnectionStrings["PizzaShopConnectionString"].ConnectionString);
            SqlCommand MyCommand = thisConnection.CreateCommand();
            SqlCommand MyCommand1 = thisConnection.CreateCommand();
            SqlCommand MyCommand2 = thisConnection.CreateCommand();
            SqlCommand MyCommand3 = thisConnection.CreateCommand();

            try
            {
                thisConnection.Open();
                MyCommand.CommandText = "INSERT INTO pizzas (size, topping_1 , topping_2) values (@size, @topping_1, @topping_2)";

                MyCommand.Parameters.Add("@size", SqlDbType.VarChar, 2);
                MyCommand.Parameters.Add("@topping_1", SqlDbType.VarChar, 10);
                MyCommand.Parameters.Add("@topping_2", SqlDbType.VarChar, 10);
                //------------------------------------------------------------------
                MyCommand.Parameters["@size"].Value = DropDownListSize.Text;
                MyCommand.Parameters["@topping_1"].Value = DropDownListTop1.Text;
                MyCommand.Parameters["@topping_2"].Value = DropDownListTop2.Text;
                MyCommand.ExecuteNonQuery();
                //---------------------------------//
                //---------------------------------//
                MyCommand2.CommandText = "INSERT INTO customer_order (drink_name , total_price,DateOfOrder) values ( @drink_name , @total_price,@DateOfOrder)";       
                MyCommand2.Parameters.Add("@drink_name", SqlDbType.VarChar, 15);
                MyCommand2.Parameters.Add("@total_price", SqlDbType.Int, 50);
                MyCommand2.Parameters.Add("@DateOfOrder", SqlDbType.DateTime, 50);
                //--------

                MyCommand2.Parameters["@drink_name"].Value = DropDownListDrink.Text;
                MyCommand2.Parameters["@total_price"].Value = Total;
                now = DateTime.Now;
                MyCommand2.Parameters["@DateOfOrder"].Value = now;
                MyCommand2.ExecuteNonQuery();
                //---------------------------------//
                MyCommand1.CommandText = "INSERT INTO customer_pizzas (customer_order_id) values (@customer_order_id)";
                MyCommand1.Parameters.Add("@customer_order_id", SqlDbType.Int, 50);
                saveOrderId(thisConnection);
                //--------
                MyCommand1.Parameters["@customer_order_id"].Value = PizzaID;
                MyCommand1.ExecuteNonQuery();

                //---------------------------------//
                MyCommand3.CommandText = "INSERT INTO customer_order_preference (customer_id ,customer_order_id ,Date) values (@customer_id , @customer_order_id , @Date)";
                MyCommand3.Parameters.Add("@customer_id", SqlDbType.Int, 50);
                MyCommand3.Parameters.Add("@customer_order_id", SqlDbType.Int, 50);
                MyCommand3.Parameters.Add("@Date", SqlDbType.DateTime, 50);
                //--------
                MyCommand3.Parameters["@customer_id"].Value = ID;
                MyCommand3.Parameters["@customer_order_id"].Value = PizzaID;
                now = DateTime.Now;
                MyCommand3.Parameters["@Date"].Value = now;
                MyCommand3.ExecuteNonQuery();




                Label4.Text = "Success";
            }

            catch (SqlException ex)
            {
                Label3.Text = "" + ex;
            }
            finally
            {
                thisConnection.Close();
                OrderNow.Enabled = false;
            }
        }
        protected void saveOrderId(SqlConnection con)
        {
            //"SELECT TOP 1 * FROM table_name DESC";
            //SELECT TOP 1[id] FROM [PizzaShop].[dbo].[customer]ORDER BY[id] DESC;
            String query1 = "Select TOP 1 id from [customer_order] ORDER BY id DESC";
            SqlCommand cmd1 = new SqlCommand(query1, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            DataTable dt = new DataTable();
            da.Fill(dt);
            string id = dt.Rows[0][0].ToString();
            PizzaID = Int32.Parse(id);
        }

        protected void Manger_Click(object sender, EventArgs e)
        {
            Response.Redirect("Manger.aspx");
        }

        protected void Logout_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("Default.aspx");
        }
    }
}