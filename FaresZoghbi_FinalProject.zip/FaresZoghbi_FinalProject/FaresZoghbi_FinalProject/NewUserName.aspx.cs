﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace FaresZoghbi_FinalProject
{
    public partial class NewUserName : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void SignUp_Click(object sender, EventArgs e)
        {

            SqlConnection thisConnection
                = new SqlConnection(ConfigurationManager.ConnectionStrings["PizzaShopConnectionString"].ConnectionString);
            SqlCommand MyCommand = thisConnection.CreateCommand();



            try
            {
                thisConnection.Open();
                MyCommand.CommandText = "INSERT INTO [user] (username, password) values (@username, @password)";

                MyCommand.Parameters.Add("@username", SqlDbType.NVarChar, 70);
                MyCommand.Parameters.Add("@password", SqlDbType.NVarChar, 70);
                //------------------------------------------------------------------
                MyCommand.Parameters["@username"].Value = TextBoxUser.Text;
                MyCommand.Parameters["@password"].Value = TextBoxPass.Text;


                MyCommand.ExecuteNonQuery();
                Label2.Text = "Success";
            }

            catch (SqlException ex)
            {
                Label1.Text = "" + ex;
            }
            finally
            {
                thisConnection.Close();
                Response.Redirect("Default.aspx");


            }

        }

    }
}