﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace FaresZoghbi_FinalProject
{
    public partial class ViewOrders : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string id = Session["id"].ToString();

            string PIZZASHOP = ConfigurationManager.ConnectionStrings["PizzaShopConnectionString"].ConnectionString;
                SqlConnection con = new SqlConnection(PIZZASHOP);
            try
            {

                SqlDataAdapter da = new SqlDataAdapter("SELECT customer_id as ID,size as Size ,topping_1 as Topping1,topping_2 as Topping2,drink_name as Drink,total_price as TotalPrice,Date FROM [customer_order_preference],[customer],[customer_order],[pizzas],[customer_pizzas] WHERE customer_order_preference.customer_id=customer.id AND customer_order_preference.customer_order_id=customer_order.id AND customer_pizzas.pizza_id=pizzas.id AND customer_pizzas.customer_order_id=customer_order.id AND customer_id = '" + id + "' ORDER BY Date ASC", con);
                DataSet ds1 = new DataSet();
                da.Fill(ds1);
                da.SelectCommand.Connection = con;
                GridView.DataSource = ds1;
                GridView.DataBind();
                Label1.Text = "All Your Orders";

            }
            catch (SqlException ex)
            {
                Label1.Text = "" + ex;
            }
            finally
            {
                con.Close();
               


            }
        }

        protected void Logout_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("Default.aspx");
        }
    }
}