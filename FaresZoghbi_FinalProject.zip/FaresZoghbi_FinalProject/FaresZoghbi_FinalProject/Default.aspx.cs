﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FaresZoghbi_FinalProject
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void loadUserSession()
        {
            HttpCookie cookie = Request.Cookies["Session"];
            if (cookie == null)
            {
                cookie = new HttpCookie("Session");
            }

            cookie["User"] = TextBoxUser.Text;

            cookie.Expires = DateTime.Now.AddMinutes(3);
            Response.Cookies.Add(cookie);
        }

        protected void saveUserId(string username, SqlConnection con)
        {
            String query1 = "Select userId from [user] where username='" + username + "'";
            SqlCommand cmd1 = new SqlCommand(query1, con);

            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            DataTable dt = new DataTable();
            da.Fill(dt);
            string id = dt.Rows[0][0].ToString();

            Session["id"] = id;
        }

        protected void Login_Click(object sender, EventArgs e)
        {
            var username = TextBoxUser.Text.ToString();
            var password = TextBoxPass.Text.ToString();

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["PizzaShopConnectionString"].ToString());
            try
            {
                con.Open();
                String query = "Select count(*) from [user] where username='" + username + "' and password='" + password + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                String value = cmd.ExecuteScalar().ToString();
                if (value == "1")
                {
                    // loadUserSession();
                    Label1.Text = "";
                    saveUserId(username, con);
                    Session["name"] = username;
                    Response.Redirect("NewOrder.aspx");
                }
                else
                {
                    Label1.Text = "Invalid Username or password";
                }
            }
            catch (SqlException ex)
            {

            }
            finally
            {
                con.Close();
            }

        }

    }
}
