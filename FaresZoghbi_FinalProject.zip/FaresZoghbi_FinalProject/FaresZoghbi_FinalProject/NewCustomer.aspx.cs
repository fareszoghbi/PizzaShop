﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace FaresZoghbi_FinalProject
{
    public partial class NewCustomer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void SubmitButton_Click(object sender, EventArgs e)
        {
            Stream fs = ImageFileUpload.PostedFile.InputStream;
            BinaryReader br = new BinaryReader(fs);
            Byte[] bytes = br.ReadBytes((Int32)fs.Length);


            SqlConnection thisConnection
                = new SqlConnection(ConfigurationManager.ConnectionStrings["PizzaShopConnectionString"].ConnectionString);
            SqlCommand MyCommand = thisConnection.CreateCommand();



            try
            {
                thisConnection.Open();
                MyCommand.CommandText = "INSERT INTO customer (FName, LName, DOB , Address ,PhoneNumber , Customer_Image , DateOfRegistration) values (@FName, @LName, @DOB , @Address,@PhoneNumber,@Customer_Image,@DateOfRegistration)";

                MyCommand.Parameters.Add("@FName", SqlDbType.NVarChar, 50);
                MyCommand.Parameters.Add("@LName", SqlDbType.NVarChar, 50);
                MyCommand.Parameters.Add("@DOB", SqlDbType.Date, 50);
                MyCommand.Parameters.Add("@Address", SqlDbType.NVarChar, 50);
                MyCommand.Parameters.Add("@PhoneNumber", SqlDbType.NVarChar, 50);
                //------------------------------------------------------------------
                MyCommand.Parameters["@FName"].Value = TextBoxFname.Text;
                MyCommand.Parameters["@LName"].Value = TextBoxLName.Text;
                MyCommand.Parameters["@DOB"].Value = DateTime.Now;

                MyCommand.Parameters["@Address"].Value = TextBoxAddress.Text;
                MyCommand.Parameters["@PhoneNumber"].Value = TextBoxPhoneNumber.Text;


                MyCommand.Parameters.Add("@Customer_Image", SqlDbType.Binary).Value = bytes;

                MyCommand.Parameters.AddWithValue("@DateOfRegistration", DateTime.Now);

                MyCommand.ExecuteNonQuery();
                Label2.Text = "Success";
            }

            catch (SqlException ex)
            {
                Label1.Text = "" + ex;
            }
            finally
            {
                thisConnection.Close();
                Response.Redirect("NewUserName.aspx");


            }

        }
    }
}